import cv2
import csv
import json
import time
from pathlib import Path
from datetime import datetime

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
FACES_DIR = DATA_DIR / "faces"
MODEL_DIR = DATA_DIR / "model"
ATTENDANCE_FILE = DATA_DIR / "attendance.csv"
LABELS_FILE = MODEL_DIR / "labels.json"
MODEL_FILE = MODEL_DIR / "face_model.yml"
CASCADE_PATH = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"

def prepare_dirs():
    FACES_DIR.mkdir(parents=True, exist_ok=True)
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if not ATTENDANCE_FILE.exists():
        with ATTENDANCE_FILE.open("w", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow(["Name", "Date", "Time", "Status"])

def clean_name(name):
    return " ".join(name.strip().split())

def register_face():
    prepare_dirs()
    name = clean_name(input("Enter person's name: "))
    if not name:
        print("Name cannot be empty.")
        return
    if not input("Confirm you have permission to collect and use this person's face data (yes/no): ").strip().lower().startswith("y"):
        print("Registration cancelled. Obtain consent first.")
        return

    person_dir = FACES_DIR / name
    person_dir.mkdir(parents=True, exist_ok=True)
    existing = list(person_dir.glob("*.jpg"))
    print("Camera starting. Look at the camera and move your head slightly.")
    print("Press Q to stop. Aim to capture 30 clear face images.")
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Could not open webcam. Check camera permissions or camera index.")
        return
    detector = cv2.CascadeClassifier(CASCADE_PATH)
    count = len(existing)
    last_capture = 0
    while count < 30:
        ok, frame = cap.read()
        if not ok:
            print("Could not read from webcam.")
            break
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = detector.detectMultiScale(gray, scaleFactor=1.2, minNeighbors=5, minSize=(80, 80))
        for (x, y, w, h) in faces:
            cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
            cv2.putText(frame, f"Images: {count}/30", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,255,0), 2)
            if time.time() - last_capture > 0.25 and count < 30:
                face = cv2.resize(gray[y:y+h, x:x+w], (200, 200))
                cv2.imwrite(str(person_dir / f"{count+1:03d}.jpg"), face)
                count += 1
                last_capture = time.time()
            break
        cv2.imshow("Register Face - Q to stop", frame)
        if cv2.waitKey(1) & 0xFF == ord("q"):
            break
    cap.release()
    cv2.destroyAllWindows()
    print(f"Saved {count} images in: {person_dir}")
    print("Next, choose Train model from the menu.")

def train_model():
    prepare_dirs()
    if not hasattr(cv2, "face"):
        print("OpenCV face module missing. Install opencv-contrib-python (not opencv-python).")
        return
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    detector = cv2.CascadeClassifier(CASCADE_PATH)
    images, labels = [], []
    label_names = {}
    label_id = 0
    for person_dir in sorted(FACES_DIR.iterdir()):
        if not person_dir.is_dir():
            continue
        person_images = sorted(person_dir.glob("*.jpg"))
        if not person_images:
            continue
        label_names[str(label_id)] = person_dir.name
        for image_path in person_images:
            img = cv2.imread(str(image_path), cv2.IMREAD_GRAYSCALE)
            if img is None:
                continue
            # Images captured by the registration flow are already face crops.
            images.append(cv2.resize(img, (200, 200)))
            labels.append(label_id)
        label_id += 1
    if not images:
        print("No face images found. Register at least one person first.")
        return
    recognizer.train(images, __import__("numpy").array(labels, dtype="int32"))
    recognizer.write(str(MODEL_FILE))
    LABELS_FILE.write_text(json.dumps(label_names, indent=2), encoding="utf-8")
    print(f"Model trained on {len(images)} images for {len(label_names)} person(s).")
    print(f"Saved model: {MODEL_FILE}")

def mark_attendance(name):
    prepare_dirs()
    now = datetime.now()
    date_str = now.strftime("%Y-%m-%d")
    time_str = now.strftime("%H:%M:%S")
    with ATTENDANCE_FILE.open("r", newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    if any(row["Name"] == name and row["Date"] == date_str for row in rows):
        return False
    with ATTENDANCE_FILE.open("a", newline="", encoding="utf-8") as f:
        csv.writer(f).writerow([name, date_str, time_str, "Present"])
    return True

def take_attendance():
    prepare_dirs()
    if not MODEL_FILE.exists() or not LABELS_FILE.exists():
        print("Model not found. Register face(s), then train the model first.")
        return
    if not hasattr(cv2, "face"):
        print("OpenCV face module missing. Install opencv-contrib-python.")
        return
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    recognizer.read(str(MODEL_FILE))
    names = json.loads(LABELS_FILE.read_text(encoding="utf-8"))
    detector = cv2.CascadeClassifier(CASCADE_PATH)
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Could not open webcam. Check camera permissions or camera index.")
        return
    print("Attendance camera running. Press Q to stop.")
    last_seen = {}
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = detector.detectMultiScale(gray, scaleFactor=1.2, minNeighbors=5, minSize=(80,80))
        for (x, y, w, h) in faces:
            face = cv2.resize(gray[y:y+h, x:x+w], (200, 200))
            label, confidence = recognizer.predict(face)
            # LBPH confidence is a distance: lower is a better match.
            if confidence < 75 and str(label) in names:
                name = names[str(label)]
                color = (0, 200, 0)
                text = f"{name} ({confidence:.0f})"
                if time.time() - last_seen.get(name, 0) > 3:
                    added = mark_attendance(name)
                    if added:
                        print(f"Attendance marked: {name}")
                    last_seen[name] = time.time()
            else:
                color = (0, 0, 255)
                text = "Unknown"
            cv2.rectangle(frame, (x,y), (x+w,y+h), color, 2)
            cv2.putText(frame, text, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
        cv2.imshow("Face Recognition Attendance - Q to stop", frame)
        if cv2.waitKey(1) & 0xFF == ord("q"):
            break
    cap.release()
    cv2.destroyAllWindows()
    print(f"Attendance CSV: {ATTENDANCE_FILE}")

def view_attendance():
    prepare_dirs()
    with ATTENDANCE_FILE.open("r", newline="", encoding="utf-8") as f:
        rows = list(csv.reader(f))
    if len(rows) <= 1:
        print("No attendance records yet.")
        return
    print("\n" + " | ".join(rows[0]))
    print("-" * 55)
    for row in rows[1:]:
        print(" | ".join(row))

def main():
    prepare_dirs()
    while True:
        print("\n===== FACE RECOGNITION ATTENDANCE SYSTEM =====")
        print("1. Register a person's face")
        print("2. Train / update recognition model")
        print("3. Start attendance")
        print("4. View attendance records")
        print("5. Exit")
        choice = input("Choose an option (1-5): ").strip()
        if choice == "1":
            register_face()
        elif choice == "2":
            train_model()
        elif choice == "3":
            take_attendance()
        elif choice == "4":
            view_attendance()
        elif choice == "5":
            print("Goodbye!")
            break
        else:
            print("Invalid option. Please choose 1-5.")

if __name__ == "__main__":
    main()
