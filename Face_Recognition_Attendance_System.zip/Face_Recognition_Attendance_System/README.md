# Face Recognition Attendance System (Python + OpenCV)

A beginner-friendly, menu-driven Python project that registers face images, trains an OpenCV LBPH recognizer, and records attendance to a CSV file.

## Features
- Register a person with webcam images (30 face crops by default).
- Train/update a face recognition model.
- Recognize registered people using a webcam.
- Mark each recognized person present only once per calendar day.
- Save attendance as `data/attendance.csv`.
- View attendance from the terminal.
- Unknown faces are labelled `Unknown`.

## Tech stack
- Python 3.10+
- OpenCV (`opencv-contrib-python`)
- NumPy
- CSV and JSON (Python standard library)

## Project structure
```text
Face_Recognition_Attendance_System/
├── attendance_system.py
├── requirements.txt
├── README.md
├── PROJECT_REPORT.md
├── .gitignore
└── data/                 # created automatically when you run the program
    ├── faces/            # registered face crops (private biometric data)
    ├── model/            # trained model and label map
    └── attendance.csv    # attendance records
```

## Setup (Windows)
1. Install Python 3.10 or newer from https://www.python.org/downloads/ and select **Add Python to PATH**.
2. Open Command Prompt in this project folder.
3. Create and activate a virtual environment:
   ```bash
   python -m venv .venv
   .venv\\Scripts\\activate
   ```
4. Install dependencies:
   ```bash
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```
5. Run:
   ```bash
   python attendance_system.py
   ```

## Setup (Linux / macOS)
```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python attendance_system.py
```

## How to use
1. Choose **1** to register a person. Enter their name and confirm you have permission to collect/use their face data. Look at the webcam; press `Q` to stop.
2. Choose **2** to train the model after registering faces. Re-train whenever you add a person.
3. Choose **3** to start attendance. A recognized person is marked `Present`; the same person is not recorded twice on the same date.
4. Choose **4** to display the CSV records.
5. Press `Q` in a webcam window to close that camera session.

### Troubleshooting
- **`module 'cv2' has no attribute 'face'`**: install `opencv-contrib-python`, then make sure you do not have both `opencv-python` and `opencv-contrib-python` installed together:
  ```bash
  pip uninstall opencv-python opencv-contrib-python -y
  pip install opencv-contrib-python
  ```
- **Camera does not open**: close other apps using the camera, check OS camera permissions, or change `cv2.VideoCapture(0)` to `cv2.VideoCapture(1)` if using an external webcam.
- **Poor recognition**: capture images in good, even lighting; keep the face visible; register again with a range of natural head positions. LBPH is a basic classroom/demo method and is not a modern high-security biometric system.

## Privacy and responsible use
- Get clear permission before registering anyone. Tell people what is collected and why.
- Face images are biometric/personal data. Keep the `data/` folder private and restrict access.
- The `.gitignore` excludes captured faces, model files, and attendance records by default. **Do not commit real people's face images or attendance records to a public GitHub repository.**
- Provide a non-biometric alternative for people who do not consent.
- This demo does not include liveness detection, anti-spoofing, access control, or production-grade security. A photo shown to the camera may be misidentified. Do not use it as the sole basis for consequential decisions.

## GitHub upload
1. Create a new empty repository on GitHub, e.g. `face-recognition-attendance-system`.
2. Keep `data/faces/`, `data/model/`, and `data/attendance.csv` out of the public repository. The included `.gitignore` does this.
3. In the project folder, run:
   ```bash
   git init
   git add .
   git status
   git commit -m "Add face recognition attendance system"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/face-recognition-attendance-system.git
   git push -u origin main
   ```
   Replace `YOUR-USERNAME` with your GitHub username. If Git is not installed, you can upload the source files using GitHub's **Add file → Upload files** page.

## License
This project is provided for educational use. Add a license file if you choose a specific open-source license.
