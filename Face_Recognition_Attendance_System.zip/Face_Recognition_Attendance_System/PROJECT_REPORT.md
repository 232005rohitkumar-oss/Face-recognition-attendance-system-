# Project Report: Face Recognition Attendance System

## 1. Title
Face Recognition Attendance System using Python and OpenCV.

## 2. Abstract
This project demonstrates an attendance workflow using a webcam and face recognition. It captures face images for consenting participants, trains an LBPH recognizer, detects faces in the live camera feed, and stores a person's attendance once per day in a CSV file.

## 3. Problem statement
Manual attendance takes time and can involve mistakes. This project explores a small, low-cost prototype that can automate a basic attendance log using a webcam.

## 4. Objectives
- Capture sample face images for registered participants.
- Train a face-recognition model using OpenCV LBPH.
- Recognize enrolled faces from a webcam feed.
- Prevent duplicate attendance entries for the same person on the same date.
- Store and display attendance records in CSV format.

## 5. Tools and technologies
- Python 3.10+
- OpenCV Contrib: face detection and LBPH recognition
- NumPy: numeric label array
- CSV: attendance storage
- JSON: label-to-name mapping
- Webcam: live image capture

## 6. System modules
1. **Face registration:** asks for a name and consent confirmation, then saves up to 30 grayscale face crops.
2. **Model training:** loads saved face crops, assigns integer labels, and trains the LBPH recognizer.
3. **Attendance:** detects faces in live video, predicts a label, and marks attendance when confidence is within the demo threshold.
4. **Attendance storage:** saves name, date, time, and status in `data/attendance.csv`.
5. **Record viewer:** prints existing attendance records in the terminal.

## 7. Methodology / algorithm
1. Start the application and create required data folders.
2. Register each participant with permission.
3. Convert captured frames to grayscale.
4. Detect faces using the Haar Cascade classifier.
5. Resize each face crop to 200 × 200 pixels and save it.
6. Train the LBPH recognizer using labelled face crops.
7. During attendance, detect a face and ask the recognizer for its closest label and confidence distance.
8. If the distance is below the configured threshold and the label exists, mark the person present unless already marked that day.
9. Save records to CSV and close the camera when the user presses Q.

## 8. Functional requirements
- Webcam access.
- Register and store face samples.
- Train/update a model.
- Recognize registered people.
- Create attendance records.
- Display attendance records.

## 9. Non-functional requirements
- Easy-to-use command-line menu.
- Runs locally without a cloud service.
- Basic maintainability through separate functions.
- Privacy-conscious default Git ignore rules.

## 10. Limitations
- Recognition accuracy depends on lighting, camera quality, and enrollment samples.
- Haar Cascade and LBPH are traditional techniques and may fail under pose or lighting changes.
- No liveness detection or anti-spoofing is included.
- The CSV file is not encrypted or protected by user accounts.
- The confidence threshold is a demo value and should be evaluated with real test data before any use beyond a classroom demonstration.

## 11. Future scope
- Add a graphical interface or web dashboard.
- Export monthly attendance reports.
- Add admin login and access controls.
- Add liveness detection and anti-spoofing.
- Add configurable classes, departments, and shift timings.
- Add audit logs and stronger storage protection.

## 12. Conclusion
The project demonstrates the basic stages of a face-recognition attendance workflow: enrollment, model training, live recognition, and attendance logging. It is suitable as a learning prototype, not as a production-grade biometric system.

## 13. Ethical and privacy note
Obtain informed permission before collecting face images. Keep biometric data and attendance logs private, provide an alternative attendance method, and avoid using this prototype for high-stakes decisions.
